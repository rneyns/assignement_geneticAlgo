function run_ga(x, y, NIND, MAXGEN, NVAR, ELITIST, STOP_PERCENTAGE, PR_CROSS, PR_MUT, CROSSOVER, LOCALLOOP, ah1, ah2, ah3)
% usage: run_ga(x, y, 
%               NIND, MAXGEN, NVAR, 
%               ELITIST, STOP_PERCENTAGE, 
%               PR_CROSS, PR_MUT, CROSSOVER, 
%               ah1, ah2, ah3)
%
%
% x, y: coordinates of the cities
% NIND: number of individuals
% MAXGEN: maximal number of generations
% ELITIST: percentage of elite population
% STOP_PERCENTAGE: percentage of equal fitness (stop criterium)
% PR_CROSS: probability for crossover
% PR_MUT: probability for mutation
% CROSSOVER: the crossover operator
% calculate distance matrix between each pair of cities
% ah1, ah2, ah3: axes handles to visualise tsp
{NIND MAXGEN NVAR ELITIST STOP_PERCENTAGE PR_CROSS PR_MUT CROSSOVER LOCALLOOP}

        %defining the parameters for the stopping treshold
        var_bestn = 0.1*MAXGEN;
        stopping_treshold = 0.05;
        GGAP = 1 - ELITIST;
        mean_fits=zeros(1,MAXGEN+1);
        worst=zeros(1,MAXGEN+1);
        Dist=zeros(NVAR,NVAR);
        for i=1:size(x,1)
            for j=1:size(y,1)
                Dist(i,j)=sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
            end
        end
        % initialize population
        Chrom=zeros(NIND,NVAR);
        for row=1:NIND
        	%Chrom(row,:)=path2adj(randperm(NVAR));
            Chrom(row,:)=randperm(NVAR);
        end
        gen=0;
        % number of individuals of equal fitness needed to stop
        stopN=ceil(STOP_PERCENTAGE*NIND);
        % evaluate initial population
        ObjV = tspfunpath(Chrom,Dist);
        best=zeros(1,MAXGEN);
        % generational loop
        var_best_mean = stopping_treshold + 1; % defining an a var_best_mean for the first var_bestn iteraties that is larger than the stopping treshold
        %starting the timer to measure runtime.
        tic
        % generational loop
        while gen<MAXGEN
            sObjV=sort(ObjV);
          	best(gen+1)=min(ObjV);
        	minimum=best(gen+1);
            mean_fits(gen+1)=mean(ObjV);
            worst(gen+1)=max(ObjV);
            for t=1:size(ObjV,1)
                if (ObjV(t)==minimum)
                    break;
                end
            end
            
            visualizeTSP(x,y,Chrom(t,:), minimum, ah1, gen, best, mean_fits, worst, ah2, ObjV, NIND, ah3);

            if (sObjV(stopN)-sObjV(1) <= 1e-15)
                  break;
            end  
            
            %calculation the variation of the best fitness to use it in the
            %stopping criterion
           if gen > var_bestn
                avg_bestn = mean(best(gen-var_bestn:gen));
                var_best = best(gen-(var_bestn):gen);
                var_best_mean = mean((var_best-avg_bestn).^2);
            end
            
            if var_best_mean < stopping_treshold
                %break;
            end
        	%assign fitness values to entire population
        	FitnV=ranking(ObjV);
        	%select individuals for breeding
            SelCh=select("rankBasedRouletteWheelSelection", Chrom, FitnV, GGAP);
            %SelCh=select("tournamentSelection", Chrom, FitnV, GGAP);
        	%SelCh=select("sus", Chrom, FitnV, GGAP);
        	%recombine individuals (crossover)
            %SelCh = recombin(CROSSOVER,SelCh,PR_CROSS);
            SelCh = recombin2(SelCh,PR_CROSS,Dist);
            SelCh = mutateTSP2(SelCh,PR_MUT,Dist);
            %evaluate offspring, call objective function
        	ObjVSel = tspfunpath(SelCh,Dist);
            %reinsert offspring into population
        	[Chrom ObjV]=reins(Chrom,SelCh,1,1,ObjV,ObjVSel);
            
            Chrom = tsp_ImprovePopulation_path(NIND, NVAR, Chrom,LOCALLOOP,Dist);
        	%increment generation counter
        	gen=gen+1;            
        end
        %stopping the time and showing the runtime
        toc;
        elapsedTime = toc
end
